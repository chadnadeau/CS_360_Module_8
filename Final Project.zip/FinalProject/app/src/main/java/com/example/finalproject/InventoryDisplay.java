package com.example.finalproject;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.RadioButton;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryDisplay extends AppCompatActivity {

    private InventoryDatabaseHelper dbHelper;
    private GridView gridView;
    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);

        dbHelper = new InventoryDatabaseHelper(this);

        gridView = findViewById(R.id.gridView);
        SearchView searchView = findViewById(R.id.searchView);
        Button editButton = findViewById(R.id.editButton);

        // Load inventory data
        loadInventoryData();

        // Set up edit button click listener
        editButton.setOnClickListener(v -> {
            isEditMode = !isEditMode;
            updateGridView();
        });
    }

    private void loadInventoryData() {
        Cursor cursor = dbHelper.getAllItems();
        InventoryCursorAdapter adapter = new InventoryCursorAdapter(this, cursor);
        gridView.setAdapter(adapter);

        // Example of handling item click (for edit functionality)
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            if (isEditMode) {
                // Toggle visibility of radio button for the clicked item
                RadioButton editRadioButton = view.findViewById(R.id.editRadioButton);
                editRadioButton.setVisibility(editRadioButton.getVisibility() == android.view.View.VISIBLE ? android.view.View.GONE : android.view.View.VISIBLE);
            } else {
                // Handle item click action (e.g., show details)
                TextView itemNameTextView = view.findViewById(R.id.item_name);
                String itemName = itemNameTextView.getText().toString();
                Toast.makeText(this, "Clicked item: " + itemName, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateGridView() {
        // Update visibility of edit radio buttons in GridView based on isEditMode flag
        for (int i = 0; i < gridView.getChildCount(); i++) {
            android.view.View view = gridView.getChildAt(i);
            RadioButton editRadioButton = view.findViewById(R.id.editRadioButton);
            editRadioButton.setVisibility(isEditMode ? android.view.View.VISIBLE : android.view.View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
