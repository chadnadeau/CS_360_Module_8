package com.example.finalproject;

import android.app.Activity;

public class EditInventory extends Activity {
}
