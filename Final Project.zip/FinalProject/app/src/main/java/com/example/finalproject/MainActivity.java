package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private UserDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new UserDbHelper(this);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccount);
        Button forgotPasswordButton = findViewById(R.id.forgotPassword);

        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (isValidUser(username, password)) {
                // Login successful, navigate to InventoryDisplayActivity
                Intent intent = new Intent(MainActivity.this, InventoryDisplay.class);
                startActivity(intent);
                // Finish the MainActivity to prevent navigating back to it using the back button
                finish();
            } else {
                // Invalid credentials, show error message
                Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {
            // Navigate to CreateAccountActivity
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });

        forgotPasswordButton.setOnClickListener(v -> {
            // Placeholder for forgot password functionality
            Toast.makeText(MainActivity.this, "Forgot Password clicked", Toast.LENGTH_SHORT).show();
        });
    }

    private boolean isValidUser(String username, String password) {
        try {
            // Check the database for the username and password
            return dbHelper.checkUserCredentials(username, password);
        } catch (Exception e) {
            e.printStackTrace();
            return false; // Handle any unexpected exceptions gracefully
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
