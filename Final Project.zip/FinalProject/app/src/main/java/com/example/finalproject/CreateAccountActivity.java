package com.example.finalproject;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class CreateAccountActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 123;
    private EditText usernameEditText, passwordEditText, enterNumber;
    private CheckBox checkBox;
    private Button createButton, sendButton;
    private UserDbHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        dbHelper = new UserDbHelper(this);
        db = dbHelper.getWritableDatabase();

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        enterNumber = findViewById(R.id.enterNumber);
        checkBox = findViewById(R.id.checkBox);
        createButton = findViewById(R.id.createButton);
        sendButton = findViewById(R.id.sendButton);

        // Check if SMS permission is granted, request if not
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        }

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePreferencesAndLogin();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can send SMS
                sendSMS("1234567890", "Hello, this is a test message!");
            } else {
                // Permission denied, handle accordingly
                Toast.makeText(CreateAccountActivity.this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void registerUser() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Assuming a simple validation for username and password
        if (!username.isEmpty() && !password.isEmpty()) {
            ContentValues values = new ContentValues();
            values.put(UserDbHelper.COLUMN_USERNAME, username);
            values.put(UserDbHelper.COLUMN_PASSWORD, password);

            long newRowId = db.insert(UserDbHelper.TABLE_USERS, null, values);
            if (newRowId != -1) {
                Toast.makeText(CreateAccountActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();

                // Redirect to InventoryDisplay upon successful registration
                Intent intent = new Intent(CreateAccountActivity.this, InventoryDisplay.class);
                startActivity(intent);
                finish(); // Optional: Close CreateAccountActivity to prevent going back on back press
            } else {
                Toast.makeText(CreateAccountActivity.this, "Error registering user", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(CreateAccountActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        }
    }

    private void savePreferencesAndLogin() {
        String phoneNumber = enterNumber.getText().toString();
        int smsEnabled = checkBox.isChecked() ? 1 : 0;

        ContentValues values = new ContentValues();
        values.put(UserDbHelper.COLUMN_SMS_ENABLED, smsEnabled);
        values.put(UserDbHelper.COLUMN_PHONE_NUMBER, phoneNumber);

        // Example: Update the user's SMS preferences
        int rowsAffected = db.update(UserDbHelper.TABLE_USERS, values,
                UserDbHelper.COLUMN_USERNAME + " = ?",
                new String[]{usernameEditText.getText().toString()});

        if (rowsAffected > 0) {
            // SMS notification logic
            if (smsEnabled == 1) {
                // Check SMS permission before sending
                if (ContextCompat.checkSelfPermission(CreateAccountActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    sendSMS(phoneNumber, "Your SMS notification settings are updated.");
                } else {
                    ActivityCompat.requestPermissions(CreateAccountActivity.this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
                    // The SMS will be sent after the user grants permission in onRequestPermissionsResult
                }
            }

            // Redirect to InventoryDisplay upon successful login
            Intent intent = new Intent(CreateAccountActivity.this, InventoryDisplay.class);
            startActivity(intent);
            finish(); // Optional: Close CreateAccountActivity to prevent going back on back press
        } else {
            Toast.makeText(CreateAccountActivity.this, "Failed to save preferences", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
